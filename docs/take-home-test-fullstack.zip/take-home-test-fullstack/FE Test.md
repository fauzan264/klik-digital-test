# Take-Home Frontend Test – CMS App

## 📝 Objective

Create a simple **CMS (Content Management System)** application using **React** or **Next.js**. The app should include:

- **Login Page**
- **Home Page**
- **Settings Page** to manage:
  - **Menu Groups**
  - **Menus**

The goal is to assess your ability to build a structured, responsive, and maintainable frontend application.

---

## 📋 Requirements

### 1. **Authentication (Login Page)**
- Simple login form (username and password).
- No need for real authentication — hardcoded credentials are acceptable.
- After login, redirect user to the Home page.

### 2. **Home Page**
- A basic landing page after login.
- Show a welcome message or any basic dashboard content.

### 3. **Settings Page**
This page allows the user to:

#### ✅ Menu Group Management
- Add new menu group.
- Remove existing menu group.
- Show list of existing menu groups.

#### ✅ Menu Management
- Add new menu under a selected group.
- Remove a menu from a group.
- List menus under each group.

### 4. **Responsiveness**
- App must be **fully responsive** (mobile, tablet, desktop).

### 5. **Tech Stack**
- Use **React** or **Next.js**.
- Feel free to use any UI library (e.g., Tailwind CSS, Material UI, Chakra UI) or build your own components.

---

## ⚙️ Optional Features (Bonus Points)

- Use a **state management library** (e.g., Zustand, Redux, Recoil, or Context API).
- Implement **form validation**.
- Save data to `localStorage` or `IndexedDB` so it persists on reload.
- Implement logout flow.
- Use TypeScript.

---

## ✅ Submission Guidelines

1. Push your project to a **GitHub repository** (public or private).
2. Include a `README.md` with:
   - How to run the project
   - Assumptions or notes
3. Share the GitHub repository link with us.

---

## ⏱️ Time Estimation

Estimated time to complete: **6-12 hours**  
You may take longer if needed, but try to balance quality and time.

---

## 💡 Evaluation Criteria

- Code clarity and structure
- Component reusability
- Responsiveness
- UI/UX quality
- Bonus implementation (if any)
- Documentation in `README.md`

---

Good luck! 🚀